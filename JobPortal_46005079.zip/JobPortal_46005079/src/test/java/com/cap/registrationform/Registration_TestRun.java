package com.cap.registrationform;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = {"C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\JobPortal_46005079\\src\\test\\resource\\Feature\\JobPortal_Features.feature"},
       glue= {"com.cap.registrationform"},
       dryRun=false,
       strict=true,
       monochrome=false,
       plugin= {"pretty","html:output"}
       )

public class Registration_TestRun {

}
