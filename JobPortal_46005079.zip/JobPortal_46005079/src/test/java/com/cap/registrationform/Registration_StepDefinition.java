package com.cap.registrationform;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.regiatrationpagefactory.Registration_PageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration_StepDefinition {
	
	WebDriver driver;
	
	Registration_PageFactory pageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void quitt() {
		driver.quit();
	}
	
	@Given("^user is on Registartion Form$")
	public void user_is_on_Registartion_Form() throws Throwable {
		driver.get("C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\JobPortal_46005079\\html\\RegistrationForm.html");
		pageFactory=new Registration_PageFactory(driver);
	}
	
	@When("^user enters the html page$")
	public void user_enters_the_html_page() throws Throwable {
		Thread.sleep(1000);
	}

	@Then("^displays 'Welcome to JobsWorld'$")
	public void displays_Welcome_to_JobsWorld() throws Throwable {
		String expectedMessage = "Welcome to JobsWorld";
		String title=driver.getTitle();
		Assert.assertEquals(expectedMessage, title);
	}

	@When("^user enters Invalid id$")
	public void user_enters_Invalid_id() throws Throwable {
		pageFactory.setUserId("");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^displays 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void displays_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectErrorMsg="User Id should not be empty / length be between 5 to 12";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}
	
	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("cap");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^display 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void display_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectErrorMsg="Password should not be empty / length be between 7 to 12";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}
	
	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^display 'Name should not be empty and must have alphabet characters only'$")
	public void display_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String expectErrorMsg="Name should not be empty and must have alphabet characters only";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("Mythili");
		pageFactory.setAddress("Sundarapuram--");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^display 'User address must have alphanumeric characters only'$")
	public void display_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		String expectErrorMsg="User address must have alphanumeric characters only";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}
	
	@When("^user enters invalid country$")
	public void user_enters_invalid_country() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("Mythili");
		pageFactory.setAddress("Sundarapuram");
		pageFactory.setCountry("");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^display 'Select your country from the list'$")
	public void display_Select_your_country_from_the_list() throws Throwable {
		String expectErrorMsg="Select your country from the list";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}

	@When("^user enters invalid zip code$")
	public void user_enters_invalid_zip_code() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("Mythili");
		pageFactory.setAddress("Sundarapuram");
		pageFactory.setCountry("India");
		pageFactory.setZipCode("");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^display 'ZIP code must have numeric characters only'$")
	public void display_ZIP_code_must_have_numeric_characters_only() throws Throwable {
		String expectErrorMsg="ZIP code must have numeric characters only";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}

	@When("^user enters invalid ename$")
	public void user_enters_invalid_ename() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("Mythili");
		pageFactory.setAddress("Sundarapuram");
		pageFactory.setCountry("India");
		pageFactory.setZipCode("641024");
		pageFactory.setEmail("myt");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}
	
	@Then("^displays 'You have entered an invalid email address!'$")
	public void displays_You_have_entered_an_invalid_email_address() throws Throwable {
		String expectErrorMsg="You have entered an invalid email address!";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}
	
	@When("^user doesnot select gender$")
	public void user_doesnot_select_gender() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("Mythili");
		pageFactory.setAddress("Sundarapuram");
		pageFactory.setCountry("India");
		pageFactory.setZipCode("641024");
		pageFactory.setEmail("mythili@gmail.com");
		pageFactory.setGender("");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^displays 'Please Select gender'$")
	public void displays_Please_Select_gender() throws Throwable {
		
		
	}

	@When("^user enters valid  registration details$")
	public void user_enters_valid_registration_details() throws Throwable {
		pageFactory.setUserId("mythili04");
		pageFactory.setPassword("capgemini");
		pageFactory.setUserName("Mythili");
		pageFactory.setAddress("Sundarapuram");
		pageFactory.setCountry("India");
		pageFactory.setZipCode("641024");
		pageFactory.setEmail("mythili@gmail.com");
		pageFactory.setGender("Female");
		pageFactory.setLanguage("English");
		pageFactory.setAbout("Hey,I am Mythili");
		pageFactory.setSubmitButton();
		Thread.sleep(1000);
	}

	@Then("^displays 'Registartion completed'$")
	public void displays_Registartion_completed() throws Throwable {
		String expectErrorMsg="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
	    String actualerrorMsg=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectErrorMsg, actualerrorMsg);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
		
	}
	
}
