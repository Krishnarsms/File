$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/mytsadas/Desktop/Module4/Testing/JobPortal_46005079/src/test/resource/Feature/JobPortal_Features.feature");
formatter.feature({
  "line": 1,
  "name": "Validting for Job Registration Form",
  "description": "",
  "id": "validting-for-job-registration-form",
  "keyword": "Feature"
});
formatter.before({
  "duration": 3256976000,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Checking title",
  "description": "",
  "id": "validting-for-job-registration-form;checking-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters the html page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "displays \u0027Welcome to JobsWorld\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 257994400,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_the_html_page()"
});
formatter.result({
  "duration": 1006003000,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.displays_Welcome_to_JobsWorld()"
});
formatter.result({
  "duration": 13147000,
  "error_message": "org.junit.ComparisonFailure: expected:\u003c[Welcome to JobsWorld]\u003e but was:\u003c[]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat com.cap.registrationform.Registration_StepDefinition.displays_Welcome_to_JobsWorld(Registration_StepDefinition.java:48)\r\n\tat ✽.Then displays \u0027Welcome to JobsWorld\u0027(C:/Users/mytsadas/Desktop/Module4/Testing/JobPortal_46005079/src/test/resource/Feature/JobPortal_Features.feature:6)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 759847600,
  "status": "passed"
});
formatter.before({
  "duration": 1312702600,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Invalid UserId",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-userid",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user enters Invalid id",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "displays \u0027User Id should not be empty / length be between 5 to 12\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 166116300,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_Invalid_id()"
});
formatter.result({
  "duration": 1195089600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5",
      "offset": 58
    },
    {
      "val": "12",
      "offset": 63
    }
  ],
  "location": "Registration_StepDefinition.displays_User_Id_should_not_be_empty_length_be_between_to(int,int)"
});
formatter.result({
  "duration": 1020800700,
  "status": "passed"
});
formatter.after({
  "duration": 777123500,
  "status": "passed"
});
formatter.before({
  "duration": 1913932400,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Invalid Password Field",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user enters invalid password",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Password should not be empty / length be between 7 to 12\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 169987500,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_invalid_password()"
});
formatter.result({
  "duration": 1329777800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7",
      "offset": 58
    },
    {
      "val": "12",
      "offset": 63
    }
  ],
  "location": "Registration_StepDefinition.display_Password_should_not_be_empty_length_be_between_to(int,int)"
});
formatter.result({
  "duration": 1026624400,
  "status": "passed"
});
formatter.after({
  "duration": 1034483300,
  "status": "passed"
});
formatter.before({
  "duration": 1484124800,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Invalid Name",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "user enters invalid name",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "display \u0027Name should not be empty and must have alphabet characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 154897800,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_invalid_name()"
});
formatter.result({
  "duration": 1322962800,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.display_Name_should_not_be_empty_and_must_have_alphabet_characters_only()"
});
formatter.result({
  "duration": 1021822800,
  "status": "passed"
});
formatter.after({
  "duration": 785565200,
  "status": "passed"
});
formatter.before({
  "duration": 1276634500,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Invalid address",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "user enters invalid address",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "display \u0027User address must have alphanumeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 538568900,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_invalid_address()"
});
formatter.result({
  "duration": 1451371000,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.display_User_address_must_have_alphanumeric_characters_only()"
});
formatter.result({
  "duration": 1020505600,
  "status": "passed"
});
formatter.after({
  "duration": 779077900,
  "status": "passed"
});
formatter.before({
  "duration": 1515123400,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Invalid country",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-country",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user enters invalid country",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "display \u0027Select your country from the list\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 216148000,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_invalid_country()"
});
formatter.result({
  "duration": 1437576800,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.display_Select_your_country_from_the_list()"
});
formatter.result({
  "duration": 1016206800,
  "status": "passed"
});
formatter.after({
  "duration": 761004500,
  "status": "passed"
});
formatter.before({
  "duration": 1387544800,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "Invalid Zip code",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-zip-code",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "user enters invalid zip code",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "display \u0027ZIP code must have numeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 118887600,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_invalid_zip_code()"
});
formatter.result({
  "duration": 1495229500,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.display_ZIP_code_must_have_numeric_characters_only()"
});
formatter.result({
  "duration": 1014563800,
  "status": "passed"
});
formatter.after({
  "duration": 775782400,
  "status": "passed"
});
formatter.before({
  "duration": 1364039000,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Invalid Email",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "user enters invalid ename",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "displays \u0027You have entered an invalid email address!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 658262800,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_invalid_ename()"
});
formatter.result({
  "duration": 1586691100,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.displays_You_have_entered_an_invalid_email_address()"
});
formatter.result({
  "duration": 1015024200,
  "status": "passed"
});
formatter.after({
  "duration": 752470200,
  "status": "passed"
});
formatter.before({
  "duration": 1637316300,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "Invalid gender",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "user doesnot select gender",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "displays \u0027Please Select gender\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 144282500,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_doesnot_select_gender()"
});
formatter.result({
  "duration": 1676797000,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.displays_Please_Select_gender()"
});
formatter.result({
  "duration": 39400,
  "status": "passed"
});
formatter.after({
  "duration": 788802600,
  "status": "passed"
});
formatter.before({
  "duration": 1269350200,
  "status": "passed"
});
formatter.scenario({
  "line": 48,
  "name": "Valid Registration details",
  "description": "",
  "id": "validting-for-job-registration-form;valid-registration-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 49,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 50,
  "name": "user enters valid  registration details",
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "displays \u0027Registartion completed\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration_StepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 201347300,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.user_enters_valid_registration_details()"
});
formatter.result({
  "duration": 1878565700,
  "status": "passed"
});
formatter.match({
  "location": "Registration_StepDefinition.displays_Registartion_completed()"
});
formatter.result({
  "duration": 1012925700,
  "status": "passed"
});
formatter.after({
  "duration": 770504200,
  "status": "passed"
});
});