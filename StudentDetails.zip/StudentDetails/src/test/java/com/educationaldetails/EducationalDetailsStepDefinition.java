package com.educationaldetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pagefactory.EducationalDetailsPageFactory;


import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationalDetailsStepDefinition {

	WebDriver Driver;
	EducationalDetailsPageFactory educationalPage;
	 @Before
		public void setUp() {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\kr89\\Desktop\\chrome\\chromedriver.exe" );
			
			Driver= new ChromeDriver();
		}
	 
	 @After
	 public void closee()
	 {
		 Driver.quit();
	 }

	
	
	@Given("^the user is on  Educational Details page$")
	public void the_user_is_on_Educational_Details_page() throws Throwable {
	    
		Driver.get("C:\\Users\\kr89\\Desktop\\WebPages Set B//EducationalDetails.html");
		educationalPage = new EducationalDetailsPageFactory(Driver);
	}

	@Then("^Checks if the title of the page is 'Educational Details'$")
	public void checks_if_the_title_of_the_page_is_Educational_Details() throws Throwable {
		 String title=Driver.getTitle();
	     Assert.assertEquals("Educational Details", title);
	}

	@Then("^Check if there is a text 'Step (\\d+): Educational Details'$")
	public void check_if_there_is_a_text_Step_Educational_Details(int arg1) throws Throwable {
		 String heading=Driver.findElement(By.xpath("//h4[@style='font-family: Calibri;']")).getText();
		 Assert.assertEquals("Step 2: Educational Details", heading);
	}

	@When("^user does'nt select Graduation$")
	public void user_does_nt_select_Graduation() throws Throwable {
		educationalPage.setGraduation("Select graduation");
		educationalPage.setRegisterBtn();
		
	}

	@Then("^display 'Please Select Graduation'$")
	public void display_Please_Select_Graduation() throws Throwable {
		 String graduation=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please Select Graduation", graduation);
		   Driver.switchTo().alert().accept();
	}

	@When("^user does'nt enter percentage$")
	public void user_does_nt_enter_percentage() throws Throwable {
		educationalPage.setGraduation("BCA");
		educationalPage.setPercentage("");
		educationalPage.setRegisterBtn();
	}

	@Then("^display 'Please fill Percentage detail'$")
	public void display_Please_fill_Percentage_detail() throws Throwable {
		String percentage=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill Percentage detail", percentage);
		   Driver.switchTo().alert().accept();
	}

	@When("^user does'nt enter Passing Year$")
	public void user_does_nt_enter_Passing_Year() throws Throwable {
		educationalPage.setGraduation("BCA");
		educationalPage.setPercentage("89");
		educationalPage.setPassYear("");
		educationalPage.setRegisterBtn();
	}

	@Then("^display 'Please fill Passing Year '$")
	public void display_Please_fill_Passing_Year() throws Throwable {
		String passYear=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill Passing Year", passYear);
		   Driver.switchTo().alert().accept();
	}

	@When("^user does'nt enter Project Name$")
	public void user_does_nt_enter_Project_Name() throws Throwable {
		educationalPage.setGraduation("BCA");
		educationalPage.setPercentage("89");
		educationalPage.setPassYear("2019");
		educationalPage.setProjectName("");
		educationalPage.setRegisterBtn();
	}

	@Then("^display 'Please fill Project Name'$")
	public void display_Please_fill_Project_Name() throws Throwable {
		String projName=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill Project Name", projName);
		   Driver.switchTo().alert().accept();
	}

	@When("^user does'nt select Technologies$")
	public void user_does_nt_select_Technologies() throws Throwable {
		educationalPage.setGraduation("BCA");
		educationalPage.setPercentage("89");
		educationalPage.setPassYear("2019");
		educationalPage.setProjectName("Student Project");
		educationalPage.setTechnology("");
		educationalPage.setRegisterBtn();
	}

	@Then("^display 'Please Select Technologies Used'$")
	public void display_Please_Select_Technologies_Used() throws Throwable {
		String tech=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please Select Technologies Used", tech);
		   Driver.switchTo().alert().accept();
	}

	@When("^user does'nt enter Other Technologies$")
	public void user_does_nt_enter_Other_Technologies() throws Throwable {
		educationalPage.setGraduation("BCA");
		educationalPage.setPercentage("89");
		educationalPage.setPassYear("2019");
		educationalPage.setProjectName("Student Project");
		educationalPage.setTechnology("Java");
	
		educationalPage.setOtherTechnologies("");
		educationalPage.setRegisterBtn();
	}

	@Then("^display 'Please fill other Technologies Used '$")
	public void display_Please_fill_other_Technologies_Used() throws Throwable {
		String otherTech="Please fill other Technologies Used";
		   Assert.assertEquals("Please fill other Technologies Used", otherTech);
		   Driver.switchTo().alert().accept();
	}

	@When("^user enters all information$")
	public void user_enters_all_information() throws Throwable {
		educationalPage.setGraduation("BCA");
		educationalPage.setPercentage("89");
		educationalPage.setPassYear("2019");
		educationalPage.setProjectName("Student Project");
		educationalPage.setTechnology("Java");
		educationalPage.setOtherTechnologies("C,C++");
		educationalPage.setRegisterBtn();
	}

	@Then("^display 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void display_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
		String result=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!", result);
		   Driver.switchTo().alert().accept();
	}
}
