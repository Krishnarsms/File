package com.personaldetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pagefactory.PersonalDetailsPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalDetailsStepDefinition {
	
	WebDriver Driver;
	PersonalDetailsPageFactory personalPage;
	 @Before
		public void setUp() {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\kr89\\Desktop\\chrome\\chromedriver.exe" );
			
			Driver= new ChromeDriver();
		}
	 
	 @After
	 public void closee()
	 {
		 Driver.quit();
	 }

	
	 @Given("^the user is on PersonalDetails page$")
	 public void the_user_is_on_PersonalDetails_page() throws Throwable {
		  Driver.get("C:\\Users\\kr89\\Desktop\\WebPages Set B\\PersonalDetails.html");
			personalPage = new PersonalDetailsPageFactory(Driver);
	    
	 }


	 @Then("^Checks if the title of the page is 'Personal Details'$")
	 public void checks_if_the_title_of_the_page_is_Personal_Details() throws Throwable {
	     String title=Driver.getTitle();
	     Assert.assertEquals("Personal Details", title);
		 
	 }

	 @Then("^Check if there is a text 'Step (\\d+): Personal Details'$")
	 public void check_if_there_is_a_text_Step_Personal_Details(int arg1) throws Throwable {
		 String heading=Driver.findElement(By.xpath("//h4[@style='font-family:Calibri;']")).getText();
		 Assert.assertEquals("Step 1: Personal Details", heading);
	     
	 }
	 
	 @When("^user does'nt enter First Name$")
	 public void user_does_nt_enter_First_Name() throws Throwable {
	    personalPage.setFname("");
	    personalPage.setNextLink();
	 }

	 @Then("^display 'Please fill the First Name'$")
	 public void display_Please_fill_the_First_Name() throws Throwable {
		 String fname=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill the First Name", fname);
		   Driver.switchTo().alert().accept();

	 }

	 @When("^user does'nt enter Last Name$")
	 public void user_does_nt_enter_Last_Name() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("");
		    personalPage.setNextLink();
	 }

	 @Then("^display 'Please fill the Last Name'$")
	 public void display_Please_fill_the_Last_Name() throws Throwable {
		 String lname=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill the Last Name", lname);
		   Driver.switchTo().alert().accept();
	 }

	 @When("^user does'nt enter Email$")
	 public void user_does_nt_enter_Email() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("");
		    personalPage.setNextLink();
	 }

	 @Then("^display 'Please fill the Email'$")
	 public void display_Please_fill_the_Email() throws Throwable {
		 String email=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill the Email", email);
		   Driver.switchTo().alert().accept();
	 }

	 @When("^user does'nt enter Contact no$")
	 public void user_does_nt_enter_Contact_no() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("");
		    personalPage.setNextLink();
	 }

	 @Then("^display 'Please fill the Contact No\\.'$")
	 public void display_Please_fill_the_Contact_No() throws Throwable {
		 String phNo=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill the Contact No.", phNo);
		   Driver.switchTo().alert().accept();
	 }

	 @When("^user enters invalid Contact no$")
	 public void user_enters_invalid_Contact_no() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("5896543210");
		    personalPage.setNextLink();
	 }

	 @Then("^display 'Please enter valid Contact No\\.'$")
	 public void display_Please_enter_valid_Contact_No() throws Throwable {
		 String phNo=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please enter valid Contact no.", phNo);
		   Driver.switchTo().alert().accept();
	 }

	 @When("^user does'nt enter AddressLine one$")
	 public void user_does_nt_enter_AddressLine_one() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("9896543210");
		 personalPage.setAddLine1("");
		 personalPage.setNextLink();
	 }
	 @Then("^display 'Please fill the address line (\\d+)' one$")
	 public void display_Please_fill_the_address_line_one(int arg1) throws Throwable {
		 String add1=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill the address line 1", add1);
		   Driver.switchTo().alert().accept();
	 }
	 
	 
	 @When("^user does'nt enter AddressLine two$")
	 public void user_does_nt_enter_AddressLine_two() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("9896543210");
		 personalPage.setAddLine1("Village Street");
		 personalPage.setAddLine2("");
		 personalPage.setNextLink();
	 }
	 
	 @Then("^display 'Please fill the address line (\\d+)' two$")
	 public void display_Please_fill_the_address_line_two(int arg1) throws Throwable {
		 
		 String add2=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please fill the address line 2", add2);
		   Driver.switchTo().alert().accept();
	 }


	 @When("^user does'nt select City$")
	 public void user_does_nt_select_City() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("9896543210");
		 personalPage.setAddLine1("Village Street");
		 personalPage.setAddLine2("Chennai");
		 personalPage.setCity("Select City");
		 personalPage.setNextLink();
	 }

	 @Then("^display 'Please select city'$")
	 public void display_Please_select_city() throws Throwable {
		 String city=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please select city", city);
		   Driver.switchTo().alert().accept();
	 }

	 @When("^user does'nt select State$")
	 public void user_does_nt_select_State() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("9896543210");
		 personalPage.setAddLine1("Village Street");
		 personalPage.setAddLine2("Chennai");
		 personalPage.setCity("Chennai");
		 personalPage.setState("Select State");
		 personalPage.setNextLink();
	 }

	 @Then("^display 'Please select state'$")
	 public void display_Please_select_state() throws Throwable {
		 String state=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Please select state", state);
		   Driver.switchTo().alert().accept();
	 }

	 @When("^user enters all information$")
	 public void user_enters_all_information() throws Throwable {
		 personalPage.setFname("Krishna");
		 personalPage.setLname("Moorthy");
		 personalPage.setEmail("Krish@gmail.com");
		 personalPage.setPhNo("9896543210");
		 personalPage.setAddLine1("Village Street");
		 personalPage.setAddLine2("Chennai");
		 personalPage.setCity("Chennai");
		 personalPage.setState("Tamilnadu");
		 personalPage.setNextLink();
	 }
	 
	 @Then("^display 'Personal details are validated and accepted successfully\\.'$")
	 public void display_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
		 String result=Driver.switchTo().alert().getText();
		   Assert.assertEquals("Personal details are validated and accepted successfully.", result);
		   Driver.switchTo().alert().accept();
	 }

	 @And("^go to 'EducationalDetals' page$")
	 public void go_to_EducationalDetals_page() throws Throwable {
	    Driver.get("C:\\Users\\kr89\\Desktop\\WebPages Set B\\EducationalDetails.html");
		 
	 }

}
